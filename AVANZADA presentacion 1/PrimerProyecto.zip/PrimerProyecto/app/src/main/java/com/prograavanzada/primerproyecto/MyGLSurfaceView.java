package com.prograavanzada.primerproyecto;

import android.content.Context;
import android.opengl.GLSurfaceView;

public class MyGLSurfaceView extends GLSurfaceView {

    private MyGLRenderer myGLRenderer;
    public MyGLSurfaceView(Context context) {
        super(context);

        setEGLContextClientVersion(2);//CONFIGURAR LA VERSION DE OPENGL ES

        myGLRenderer = new MyGLRenderer();
        setRenderer(myGLRenderer);
    }
}
