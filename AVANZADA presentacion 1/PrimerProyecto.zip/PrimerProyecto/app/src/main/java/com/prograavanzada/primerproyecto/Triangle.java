package com.prograavanzada.primerproyecto;

import static com.prograavanzada.primerproyecto.MyGLRenderer.loadShader;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

/**
 * Clase que representa un triángulo geométrico en el espacio 3D/2D para OpenGL ES 2.0.
 *
 * Se encarga de:
 * 1. Reservar memoria nativa (fuera de la JVM) para enviarla a la GPU.
 * 2. Cargar y compilar los shaders (Vertex Shader y Fragment Shader).
 * 3. Enlazar los shaders en un programa ejecutable de OpenGL (mProgram).
 * 4. Enviar las coordenadas y el color a la GPU para renderizar la figura.
 */
public class Triangle {

    // Búfer en memoria nativa directa que almacena las coordenadas de los vértices.
    // La GPU no puede leer datos gestionados directamente por el Recolector de Basura de Java.
    private final FloatBuffer vertexBuffer;

    // Identificador único generado por OpenGL para el programa de shaders enlazado.
    private final int mProgram;

    // Puentes (handles) para conectar variables de Java con las variables del código GLSL:
    // - positionHandle: Apunta a "vPosition" en el Vertex Shader (tipo attribute).
    // - colorHandle: Apunta a "vColor" en el Fragment Shader (tipo uniform).
    private int positionHandle, colorHandle;

    // Número de componentes numéricas por vértice en el espacio cartesiano (X, Y, Z).
    static final int COORDS_PER_VERTEX = 3;

    // Coordenadas cartesianas normalizadas de OpenGL (rango de -1.0 a 1.0).
    // Definimos los 3 vértices que forman el triángulo:
    // 1. Vértice superior: (X: 0.0, Y: -0.25, Z: 0.0)
    // 2. Vértice inferior izquierdo: (X: -0.5, Y: -0.75, Z: 0.0)
    // 3. Vértice inferior derecho: (X: 0.5, Y: -0.75, Z: 0.0)
    static float[] triangleCoords = {
            0.0f, -0.25f, 0.0f, // Vértice 1 (Arriba)
            -0.5f, -0.75f, 0.0f, // Vértice 2 (Abajo izquierda)
            0.5f, -0.75f, 0.0f,  // Vértice 3 (Abajo derecha)

            -0.250f, -0.0f, 0.0f, // Vértice 1 (Arriba)
            -0.75f, -0.5f, 0.0f, // Vértice 2 (Abajo izquierda)
            -0.75f, 0.5f, 0.0f,  // Vértice 3 (Abajo derecha)
    };

    // Cantidad de vértices totales que componen la figura (3 en este caso).
    private final int vertexCount = triangleCoords.length / COORDS_PER_VERTEX;

    // Zancada (Stride): Cantidad de bytes que ocupa cada vértice completo en la memoria (3 coordenadas * 4 bytes por float).
    private final int vertexStride = COORDS_PER_VERTEX * 4;

    // Color asignado al triángulo en formato RGBA (Rojo, Verde, Azul, Alfa/Opacidad).
    // Valores entre 0.0f y 1.0f. (En este caso configurado como un rojo brillante y opaco).
    float[] color = { .63f, 0.73f, 0.22f, 1.0f };

    // A. El Vertex Shader (El geómetra):
    // Su trabajo es recibir las coordenadas de cada vértice y definir su posición espacial en la pantalla.
    private final String vertexShaderCode =
            "attribute vec4 vPosition;" + // Recibe la posición (X, Y, Z, W) enviada desde Java.
                    "void main() {" +
                    "  gl_Position = vPosition;" + // Variable nativa de OpenGL donde se almacena la posición final.
                    "}";

    // B. El Fragment Shader (El pintor):
    // Se encarga de rasterizar y pintar cada píxel que conforma el interior del triángulo con un color sólido.
    private final String fragmentShaderCode =
            "precision mediump float;" +  // Define una precisión de cálculo estándar para los decimales en dispositivos móviles.
                    "uniform vec4 vColor;" +      // Recibe el color RGBA constante enviado desde Java.
                    "void main() {" +
                    "  gl_FragColor = vColor;" +   // Asigna el color final a cada fragmento (píxel) visible.
                    "}";

    /**
     * Constructor de la clase Triangle.
     * Inicializa la memoria nativa de la GPU y compila/enlaza los shaders necesarios.
     */
    public Triangle() {
        // Paso 1: Reservamos espacio en la memoria nativa del sistema fuera de la JVM.
        // Multiplicamos el tamaño del arreglo por 4 porque cada dato tipo float consume 4 bytes.
        ByteBuffer bb = ByteBuffer.allocateDirect(triangleCoords.length * 4);

        // Paso 2: Ordenamos los bytes según la arquitectura del procesador (Native Order / Endianness).
        bb.order(ByteOrder.nativeOrder());

        // Paso 3: Convertimos el búfer de bytes crudos a un búfer de tipo FloatBuffer.
        vertexBuffer = bb.asFloatBuffer();

        // Paso 4: Copiamos las coordenadas del arreglo de Java hacia el búfer nativo.
        vertexBuffer.put(triangleCoords);

        // Paso 5: Reposicionamos el puntero del búfer al inicio (índice 0) para que la GPU lea desde el principio.
        vertexBuffer.position(0);

        // Paso 6: Compilamos los códigos fuente de los shaders (Vertex y Fragment).
        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        // Paso 7: Creamos el programa contenedor en la tarjeta gráfica.
        mProgram = GLES20.glCreateProgram();

        // Paso 8: Adjuntamos ambos shaders compilados al programa.
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);

        // Paso 9: Enlazamos el programa ejecutable de OpenGL.
        GLES20.glLinkProgram(mProgram);
    }

    /**
     * Método auxiliar para compilar un shader individual dentro de la GPU.
     *
     * @param type       Tipo de shader (GLES20.GL_VERTEX_SHADER o GLES20.GL_FRAGMENT_SHADER).
     * @param shaderCode El código fuente escrito en lenguaje GLSL.
     * @return El identificador numérico único del shader compilado.
     */


    /**
     * Método de dibujo (draw).
     * Se ejecuta de forma repetitiva en cada frame dentro del ciclo de renderizado para proyectar el triángulo en pantalla.
     */
    public void draw() {
        // 1. Activamos el programa de shaders en la GPU.
        GLES20.glUseProgram(mProgram);

        // 2. Obtenemos el identificador/referencia de la variable `vPosition` en el Vertex Shader.
        positionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");

        // 3. Habilitamos la lectura de la matriz de atributos de vértices en la GPU.
        GLES20.glEnableVertexAttribArray(positionHandle);

        // 4. Configuramos el puntero de los atributos de vértices para que la GPU sepa cómo interpretar los datos:
        // - positionHandle: Referencia del atributo.
        // - COORDS_PER_VERTEX (3): Componentes por vértice (X, Y, Z).
        // - GLES20.GL_FLOAT: Tipo de dato almacenado.
        // - false: Si los valores deben normalizarse (los dejamos en false ya que están normalizados por software).
        // - vertexStride: Distancia en bytes entre el inicio de un vértice y el siguiente.
        // - vertexBuffer: El búfer nativo que contiene los datos de coordenadas.
        GLES20.glVertexAttribPointer(
                positionHandle,
                COORDS_PER_VERTEX,
                GLES20.GL_FLOAT,
                false,
                vertexStride,
                vertexBuffer
        );

        // 5. Obtenemos el identificador de la variable uniforme de color (`vColor`) en el Fragment Shader.
        colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");

        // 6. Enviamos el color RGBA definido en Java hacia la variable uniforme de la GPU.
        GLES20.glUniform4fv(colorHandle, 1, color, 0);

        // 7. Ordenamos a OpenGL que dibuje la geometría en pantalla:
        // - GLES20.GL_TRIANGLES: Dibuja triángulos cerrados conectando los vértices en grupos de 3.
        // - 0: Índice de inicio en el búfer.
        // - vertexCount (3): Cantidad total de vértices a renderizar.
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount);

        // 8. Desactivamos el canal del atributo de posición para mantener limpia la memoria de la GPU tras el dibujado.
        GLES20.glDisableVertexAttribArray(positionHandle);
    }
}