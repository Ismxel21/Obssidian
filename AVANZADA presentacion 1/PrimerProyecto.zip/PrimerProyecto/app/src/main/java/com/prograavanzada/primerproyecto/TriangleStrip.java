package com.prograavanzada.primerproyecto;

import static com.prograavanzada.primerproyecto.MyGLRenderer.loadShader;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class TriangleStrip {

    private final FloatBuffer vertexBuffer;
    private final int mProgram;

    // Solo manejamos el handle de la posición y el nuevo atributo adicional
    private int positionHandle;

    // Coordenadas y un atributo extra intercalado (por ejemplo, un valor de opacidad/atenuación por vértice)
    // Estructura por vértice: [X, Y, Z, Alpha] -> 4 valores por cada punto
    static float[] stripData = {
            -0.8f,  -0.2f,
            -0.4f, -0.2f,
            -0.8f,  0.2f,
            -0.4f, 0.2f,
            -.4f, .6f,

    };


    // Vertex Shader: Incluye la posición y un nuevo atributo adicional (`aAlpha`)
    private final String vertexShaderCode =
            "attribute vec4 vPosition;" +
                    "void main() {" +
                    "  gl_Position = vPosition;" +
                    "}";

    // Fragment Shader: Pinta usando el atributo recibido sin necesidad de colorHandle externo
    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "varying float outAlpha;" +
                    "void main() {" +
                    "  gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);" + // Color cian modulado por el atributo alpha
                    "}";

    public TriangleStrip() {
        // Reservar memoria nativa (cada float son 4 bytes)
        ByteBuffer bb = ByteBuffer.allocateDirect(stripData.length * 4);
        bb.order(ByteOrder.nativeOrder());

        vertexBuffer = bb.asFloatBuffer();
        vertexBuffer.put(stripData);
        vertexBuffer.position(0);

        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);
    }



    public void draw() {
        GLES20.glUseProgram(mProgram);

        // 1. Configurar el atributo de posición (vPosition)
        positionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
        GLES20.glEnableVertexAttribArray(positionHandle);

     GLES20.glVertexAttribPointer(
                positionHandle,
                2,                  // 3 componentes para la posición (X, Y, Z)
                GLES20.GL_FLOAT,
                false,
0,
             vertexBuffer
        );



        // Renderizar la tira de triángulos
   GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 5);

        // Limpieza de atributos
        GLES20.glDisableVertexAttribArray(positionHandle);
    }
}