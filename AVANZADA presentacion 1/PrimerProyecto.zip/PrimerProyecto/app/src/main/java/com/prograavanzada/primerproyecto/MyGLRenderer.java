package com.prograavanzada.primerproyecto;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;


import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {

   // private Point point;
 // private Line line;
    private Triangle triangle;

    private TriangleStrip triangleStrip;
    private Circle circle;
    private Circle circleEspejo;
    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Color de fondo (RGBA)
     //   point = new Point();
        //triangle = new Triangle();
   // triangleStrip = new TriangleStrip();
        circle = new Circle(0.25f, 90, .5f,-.6f,.0f);
        circleEspejo = new Circle(0.2f, 20, -0.5f, 0.5f, 0.0f);
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0, 0, width, height);

    }

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        circle.draw();
        circleEspejo.draw();
  //      point.draw();
        //triangle.draw();
       // triangleStrip.draw();
    }
    public static int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        return shader;
    }
}
