package com.prograavanzada.primerproyecto;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;

public class Circle {
    private final FloatBuffer vertexBuffer;
    // ID del programa OpenGL que contiene los shaders compilados y enlazados
    private final int mProgram;
    private int positionHandle, colorHandle;

    private final int COORDS_POR_VERTEX = 3;
    float color[] = {0.8f, 0.67f, 1.0f, 1.0f};
    private final int vertexCount;
    private final int vertexStride = COORDS_POR_VERTEX * 4;
    private float[] circleCoords;

    // Método corregido recibiendo las coordenadas del centro (cx, cy, cz)
    private float[] createCircleCoords(float radius, int numPoints, float cx, float cy, float cz) {
        List<Float> coords = new ArrayList<>();

        // 1. Centro del círculo (x, y, z)
        coords.add(cx);
        coords.add(cy);
        coords.add(cz);
        double angle = 2.0 * Math.PI / numPoints;

        for (int i = 0; i <= numPoints; i++) {
            double angle2 = angle * i;
            coords.add((float) (radius * Math.cos(angle2)) + cx); // x
            coords.add((float) (radius * Math.sin(angle2)) + cy); // y
            coords.add(cz);
        }

        // Convertir List<Float> a un arreglo primitivo float[]
        float[] arrayVertex = new float[coords.size()];
        for (int i = 0; i < coords.size(); i++) {
            arrayVertex[i] = coords.get(i);
        }
        return arrayVertex;
    }

    // Código de Shaders básicos para renderizar el color plano
    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
                    "attribute vec4 vPosition;" +
                    "void main() {" +
                    "  gl_Position = vPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "uniform vec4 vColor;" +
                    "void main() {" +
                    "  gl_FragColor = vColor;" +
                    "}";


    public Circle(float radius, int numPoints, float cx, float cy, float cz) {
        circleCoords = createCircleCoords(radius, numPoints, cx, cy, cz);
        vertexCount = circleCoords.length / COORDS_POR_VERTEX;

        ByteBuffer bb = ByteBuffer.allocateDirect(circleCoords.length * 4);
        bb.order(ByteOrder.nativeOrder());
        vertexBuffer = bb.asFloatBuffer();
        vertexBuffer.put(circleCoords);
        vertexBuffer.position(0);

        int vertexShader = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);
    }

    public void draw() {
        GLES20.glUseProgram(mProgram);

        positionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
        GLES20.glEnableVertexAttribArray(positionHandle);

        GLES20.glVertexAttribPointer(
                positionHandle,
                COORDS_POR_VERTEX,
                GLES20.GL_FLOAT,
                false,
                vertexStride,
                vertexBuffer
        );

        colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
        GLES20.glUniform4fv(colorHandle, 1, color, 0);

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, vertexCount);

        GLES20.glDisableVertexAttribArray(positionHandle);
    }
}